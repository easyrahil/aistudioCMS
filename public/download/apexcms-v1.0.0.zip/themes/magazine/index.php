<?php
include __DIR__ . '/header.php';
?>
<main class="container">
    <?php foreach ($blocks as $block): ?>
        <?php if (!($block['enabled'] ?? true)) continue; ?>
        
        <?php if ($block['type'] === 'hero'): ?>
            <section style="padding: 60px 0; text-align: center;">
                <h1 style="font-size: 42px; font-weight: 800; color: #f8fafc; max-width: 800px; margin: 0 auto 16px;"><?= htmlspecialchars($block['settings']['title'] ?? '') ?></h1>
                <p style="font-size: 18px; color: #94a3b8; max-width: 650px; margin: 0 auto 30px;"><?= htmlspecialchars($block['settings']['subtitle'] ?? '') ?></p>
                <div style="display: flex; gap: 12px; justify-content: center;">
                    <a href="<?= htmlspecialchars($block['settings']['cta_link'] ?? '#') ?>" style="background: #2563eb; color: white; padding: 12px 24px; border-radius: 8px; text-decoration: none; font-weight: 600;"><?= htmlspecialchars($block['settings']['cta_text'] ?? 'Explore') ?></a>
                    <?php if ($shopEnabled && !empty($block['settings']['secondary_cta_text'])): ?>
                        <a href="<?= htmlspecialchars($block['settings']['secondary_cta_link'] ?? '/shop') ?>" style="background: #1e293b; color: #38bdf8; border: 1px solid #334155; padding: 12px 24px; border-radius: 8px; text-decoration: none; font-weight: 600;"><?= htmlspecialchars($block['settings']['secondary_cta_text']) ?></a>
                    <?php endif; ?>
                </div>
            </section>

        <?php elseif ($block['type'] === 'featured_posts'): ?>
            <section id="articles" style="margin: 60px 0;">
                <h2 style="font-size: 26px; border-left: 4px solid #38bdf8; padding-left: 12px; margin-bottom: 24px;"><?= htmlspecialchars($block['settings']['title'] ?? 'Articles') ?></h2>
                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 24px;">
                    <?php foreach ($posts as $post): ?>
                        <article style="background: #131b2e; border: 1px solid #1e293b; border-radius: 12px; overflow: hidden; padding: 20px;">
                            <span style="font-size: 12px; color: #38bdf8; font-weight: 600; text-transform: uppercase;">Technical Article</span>
                            <h3 style="margin: 10px 0; font-size: 18px;"><a href="/post/<?= $post['slug'] ?>" style="color: white; text-decoration: none;"><?= htmlspecialchars($post['title']) ?></a></h3>
                            <p style="color: #94a3b8; font-size: 14px; margin-bottom: 16px;"><?= htmlspecialchars($post['excerpt'] ?? '') ?></p>
                            <a href="/post/<?= $post['slug'] ?>" style="color: #38bdf8; font-size: 14px; font-weight: 600; text-decoration: none;">Read essay &rarr;</a>
                        </article>
                    <?php endforeach; ?>
                </div>
            </section>

        <?php elseif ($block['type'] === 'featured_products' && $shopEnabled): ?>
            <section style="margin: 60px 0;">
                <h2 style="font-size: 26px; border-left: 4px solid #10b981; padding-left: 12px; margin-bottom: 24px;"><?= htmlspecialchars($block['settings']['title'] ?? 'Store Products') ?></h2>
                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(240px, 1fr)); gap: 24px;">
                    <?php foreach ($products as $pr): ?>
                        <div style="background: #131b2e; border: 1px solid #1e293b; border-radius: 12px; padding: 20px; display: flex; flex-direction: column; justify-content: space-between;">
                            <div>
                                <span style="font-size: 11px; background: #064e3b; color: #6ee7b7; padding: 2px 6px; border-radius: 4px;"><?= strtoupper($pr['type'] ?? 'PHYSICAL') ?></span>
                                <h3 style="margin: 10px 0 6px; font-size: 17px;"><a href="/product/<?= $pr['slug'] ?>" style="color: white; text-decoration: none;"><?= htmlspecialchars($pr['title']) ?></a></h3>
                                <p style="font-weight: 700; color: #38bdf8; font-size: 18px;">$<?= number_format((float)$pr['price'], 2) ?></p>
                            </div>
                            <form method="POST" action="/cart/add" style="margin-top: 14px;">
                                <input type="hidden" name="product_id" value="<?= $pr['id'] ?>">
                                <button type="submit" style="width: 100%; background: #059669; color: white; border: none; padding: 10px; border-radius: 6px; font-weight: 600; cursor: pointer;">Add to Cart</button>
                            </form>
                        </div>
                    <?php endforeach; ?>
                </div>
            </section>

        <?php elseif ($block['type'] === 'faq'): ?>
            <section style="margin: 60px 0; max-width: 800px; margin-left: auto; margin-right: auto;">
                <h2 style="text-align: center; font-size: 26px; margin-bottom: 24px;"><?= htmlspecialchars($block['settings']['title'] ?? 'FAQ') ?></h2>
                <?php foreach (($block['settings']['items'] ?? []) as $item): ?>
                    <details style="background: #131b2e; border: 1px solid #1e293b; border-radius: 8px; margin-bottom: 12px; padding: 14px 18px;">
                        <summary style="font-weight: 600; cursor: pointer; color: #38bdf8;"><?= htmlspecialchars($item['q']) ?></summary>
                        <p style="margin-top: 10px; color: #94a3b8; font-size: 14px;"><?= htmlspecialchars($item['a']) ?></p>
                    </details>
                <?php endforeach; ?>
            </section>
        <?php endif; ?>
    <?php endforeach; ?>
</main>
<?php
include __DIR__ . '/footer.php';
?>
