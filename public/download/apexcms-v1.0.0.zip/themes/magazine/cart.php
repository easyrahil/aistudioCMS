<?php
include __DIR__ . '/header.php';
?>
<main class="container" style="max-width: 700px;">
    <h1 style="font-size: 30px; font-weight: 800; margin-bottom: 24px;">Your Shopping Cart</h1>
    <?php if (empty($cart)): ?>
        <p style="color: #94a3b8;">Your cart is currently empty. <a href="/shop" style="color: #38bdf8;">Browse products</a></p>
    <?php else: ?>
        <div style="background: #131b2e; border: 1px solid #1e293b; border-radius: 12px; padding: 24px;">
            <p>You have <?= array_sum($cart) ?> item(s) ready for checkout.</p>
            <a href="/checkout" style="display: block; text-align: center; background: #059669; color: white; padding: 14px; border-radius: 8px; text-decoration: none; font-weight: 700;">Proceed to Secure Checkout &rarr;</a>
        </div>
    <?php endif; ?>
</main>
<?php
include __DIR__ . '/footer.php';
?>
