<?php
include __DIR__ . '/header.php';
?>
<main class="container" style="max-width: 800px; padding: 40px 20px;">
    <article>
        <div style="font-size: 11px; font-weight: 700; text-transform: uppercase; color: #2563eb; letter-spacing: 1px; margin-bottom: 8px;">
            Official Page • Template: <?= htmlspecialchars($page['template'] ?? 'default') ?>
        </div>
        <h1 style="font-size: 34px; font-weight: 900; line-height: 1.25; margin-bottom: 20px; color: #0f172a;">
            <?= htmlspecialchars($page['title']) ?>
        </h1>
        <div class="article-body" style="font-size: 16px; line-height: 1.8; color: #334155; border-top: 1px solid #e2e8f0; padding-top: 24px;">
            <?= $page['body'] ?>
        </div>
    </article>
</main>
<?php
include __DIR__ . '/footer.php';
?>
