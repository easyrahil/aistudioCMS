<?php
include __DIR__ . '/header.php';
?>
<main class="container" style="max-width: 800px;">
    <article>
        <h1 style="font-size: 38px; font-weight: 800; line-height: 1.25; margin-bottom: 12px;"><?= htmlspecialchars($post['title']) ?></h1>
        <div style="display: flex; gap: 16px; color: #94a3b8; font-size: 14px; margin-bottom: 30px; border-bottom: 1px solid #1e293b; padding-bottom: 16px;">
            <span>By <?= htmlspecialchars($post['author_name'] ?? 'Apex Staff') ?></span>
            <span>&bull;</span>
            <span>Published on <?= date('F j, Y', strtotime($post['created_at'])) ?></span>
        </div>
        <div class="article-body" style="font-size: 17px; line-height: 1.8; color: #cbd5e1;">
            <?= $post['body'] ?>
        </div>
    </article>
</main>
<?php
include __DIR__ . '/footer.php';
?>
