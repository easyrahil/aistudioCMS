<?php
include __DIR__ . '/header.php';
?>
<main class="container">
    <div style="border-bottom: 1px solid #1e293b; padding-bottom: 20px; margin-bottom: 32px;">
        <h1 style="font-size: 32px; font-weight: 800; margin: 0 0 8px;">Official Product Catalog</h1>
        <p style="color: #94a3b8; margin: 0;">Physical merchandise & instant tokenized digital downloads.</p>
    </div>
    <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(260px, 1fr)); gap: 24px;">
        <?php foreach ($products as $pr): ?>
            <div style="background: #131b2e; border: 1px solid #1e293b; border-radius: 12px; padding: 20px;">
                <span style="font-size: 11px; background: #064e3b; color: #6ee7b7; padding: 2px 6px; border-radius: 4px;"><?= strtoupper($pr['type']) ?></span>
                <h3 style="margin: 12px 0 6px;"><a href="/product/<?= $pr['slug'] ?>" style="color: white; text-decoration: none;"><?= htmlspecialchars($pr['title']) ?></a></h3>
                <p style="font-size: 20px; font-weight: 700; color: #38bdf8; margin: 8px 0 16px;">$<?= number_format((float)$pr['price'], 2) ?></p>
                <form method="POST" action="/cart/add">
                    <input type="hidden" name="product_id" value="<?= $pr['id'] ?>">
                    <button type="submit" style="width: 100%; background: #2563eb; color: white; border: none; padding: 10px; border-radius: 6px; font-weight: 600; cursor: pointer;">Add to Cart</button>
                </form>
            </div>
        <?php endforeach; ?>
    </div>
</main>
<?php
include __DIR__ . '/footer.php';
?>
