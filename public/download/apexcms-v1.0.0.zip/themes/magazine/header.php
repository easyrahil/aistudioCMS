<?php
use Apex\Models\Setting;
$siteName = Setting::get('site_name', 'ApexCMS');
$shopEnabled = (bool)Setting::get('shop_enabled', '1');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($title ?? $siteName) ?></title>
    <style>
        :root { --accent: #2563eb; --bg: #090d16; --card: #131b2e; --text: #f1f5f9; --text-muted: #94a3b8; --border: #1e293b; }
        body { margin: 0; font-family: system-ui, -apple-system, sans-serif; background: var(--bg); color: var(--text); line-height: 1.6; }
        .site-header { border-bottom: 1px solid var(--border); background: rgba(9, 13, 22, 0.85); backdrop-filter: blur(8px); position: sticky; top: 0; z-index: 50; }
        .nav-container { max-width: 1200px; margin: 0 auto; display: flex; align-items: center; justify-content: space-between; padding: 14px 20px; }
        .site-logo { font-size: 20px; font-weight: 800; color: #38bdf8; text-decoration: none; display: flex; align-items: center; gap: 8px; }
        .nav-links { display: flex; list-style: none; margin: 0; padding: 0; gap: 20px; }
        .nav-links a { color: var(--text-muted); text-decoration: none; font-size: 14px; font-weight: 500; transition: color 0.2s; }
        .nav-links a:hover, .nav-links a.active { color: #38bdf8; }
        .badge-shop { background: #059669; color: white; padding: 2px 6px; border-radius: 4px; font-size: 11px; margin-left: 4px; }
        .container { max-width: 1200px; margin: 0 auto; padding: 40px 20px; }
    </style>
</head>
<body>
<header class="site-header">
    <div class="nav-container">
        <a href="/" class="site-logo">
            <span>⚡</span> <?= htmlspecialchars($siteName) ?>
        </a>
        <nav>
            <ul class="nav-links">
                <li><a href="/">Home</a></li>
                <li><a href="/#articles">Essays</a></li>
                <?php if ($shopEnabled): ?>
                    <li><a href="/shop">Store <span class="badge-shop">Shop</span></a></li>
                    <li><a href="/cart">Cart</a></li>
                <?php endif; ?>
                <li><a href="/admin/" style="color: #a855f7;">Admin Suite &rarr;</a></li>
            </ul>
        </nav>
    </div>
</header>
