<?php
include __DIR__ . '/header.php';
?>
<main class="container" style="max-width: 600px;">
    <h1 style="font-size: 28px; font-weight: 800; margin-bottom: 20px;">Secure Checkout</h1>
    <?php if (isset($_GET['success'])): ?>
        <div style="background: #10b98120; border: 1px solid #10b981; color: #6ee7b7; padding: 24px; border-radius: 12px; text-align: center;">
            <h2>🎉 Order Confirmed!</h2>
            <p>Thank you for your purchase. If your order contains digital products, secure download tokens have been generated.</p>
            <a href="/" style="color: #38bdf8;">Return Home</a>
        </div>
    <?php else: ?>
        <form method="POST" action="/checkout" style="background: #131b2e; border: 1px solid #1e293b; border-radius: 12px; padding: 24px;">
            <div style="margin-bottom: 16px;">
                <label style="display:block; margin-bottom: 6px;">Full Name</label>
                <input type="text" name="customer_name" required style="width:100%; box-sizing: border-box; padding: 10px; background: #090d16; border: 1px solid #334155; border-radius: 6px; color: white;">
            </div>
            <div style="margin-bottom: 16px;">
                <label style="display:block; margin-bottom: 6px;">Email Address</label>
                <input type="email" name="customer_email" required style="width:100%; box-sizing: border-box; padding: 10px; background: #090d16; border: 1px solid #334155; border-radius: 6px; color: white;">
            </div>
            <div style="margin-bottom: 24px;">
                <label style="display:block; margin-bottom: 6px;">Payment Method</label>
                <select name="payment_method" style="width:100%; box-sizing: border-box; padding: 10px; background: #090d16; border: 1px solid #334155; border-radius: 6px; color: white;">
                    <option value="stripe">Credit Card (Stripe Driver)</option>
                    <option value="paypal">PayPal Express</option>
                    <option value="cod">Cash on Delivery</option>
                </select>
            </div>
            <button type="submit" style="width: 100%; background: #2563eb; color: white; padding: 14px; border: none; border-radius: 8px; font-weight: 700; cursor: pointer;">Place Order Now &rarr;</button>
        </form>
    <?php endif; ?>
</main>
<?php
include __DIR__ . '/footer.php';
?>
