<?php
include __DIR__ . '/header.php';
?>
<main class="container" style="text-align: center; padding: 80px 20px;">
    <h1 style="font-size: 64px; font-weight: 900; color: #ef4444; margin: 0;">404</h1>
    <h2 style="font-size: 24px; margin: 12px 0 20px;">Document Not Found</h2>
    <p style="color: #94a3b8; max-width: 500px; margin: 0 auto 30px;">The resource you requested has either migrated to a canonical URI or does not exist.</p>
    <a href="/" style="background: #2563eb; color: white; padding: 12px 24px; border-radius: 8px; text-decoration: none; font-weight: 600;">Return to Safety</a>
</main>
<?php
include __DIR__ . '/footer.php';
?>
