<?php
use Apex\Models\Setting;
?>
<footer style="border-top: 1px solid #1e293b; background: #0b1120; padding: 40px 20px; margin-top: 80px; text-align: center; color: #64748b; font-size: 14px;">
    <div style="max-width: 1200px; margin: 0 auto;">
        <p>&copy; <?= date('Y') ?> <?= htmlspecialchars(Setting::get('site_name', 'ApexCMS')) ?>. Powered by ApexCMS Enterprise Core.</p>
        <p><a href="/sitemap.xml" style="color: #38bdf8;">XML Sitemap</a> | <a href="/robots.txt" style="color: #38bdf8;">Robots.txt</a> | <a href="/feed" style="color: #38bdf8;">RSS Feed</a></p>
    </div>
</footer>
</body>
</html>
