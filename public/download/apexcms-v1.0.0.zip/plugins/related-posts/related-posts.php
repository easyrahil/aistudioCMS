<?php
declare(strict_types=1);

use Apex\Core\Hook;
use Apex\Models\Post;

Hook::addFilter('the_content', function(string $content, array $post) {
    $related = Post::getPublished(2);
    if (!empty($related)) {
        $box = "<section class='related-posts-box' style='margin-top:40px; padding-top:20px; border-top:1px solid #1e293b;'><h4 style='margin-bottom:12px;'>Further Reading</h4><div style='display:grid; grid-template-columns:1fr 1fr; gap:16px;'>";
        foreach ($related as $r) {
            if ($r['slug'] === ($post['slug'] ?? '')) continue;
            $box .= "<div style='background:#131b2e; padding:12px; border-radius:8px;'><a href='/post/{$r['slug']}' style='color:#38bdf8; font-weight:600; text-decoration:none;'>" . htmlspecialchars($r['title']) . "</a></div>";
        }
        $box .= "</div></section>";
        return $content . $box;
    }
    return $content;
});
