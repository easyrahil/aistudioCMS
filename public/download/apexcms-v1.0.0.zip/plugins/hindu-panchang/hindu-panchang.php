<?php
declare(strict_types=1);

namespace Apex\Plugins\HinduPanchang;

use Apex\Core\Hook;

Hook::addAction('init_tools', function () {
    // Register astronomical panchang tool
});

Hook::addFilter('content_tools_list', function (array $tools) {
    $tools[] = [
        'id' => 'hindu-panchang-calculator',
        'name' => 'Indian Vrat & Festival Panchang Calculator',
        'badge' => 'Astronomical Engine',
        'status' => 'Active'
    ];
    return $tools;
});
