<?php
declare(strict_types=1);

use Apex\Core\Hook;

Hook::addFilter('the_content', function(string $content, array $post) {
    if (preg_match_all('/<h([2-3])>(.*?)<\/h[2-3]>/i', $content, $matches, PREG_SET_ORDER)) {
        $toc = "<nav aria-label='Table of Contents' class='toc-box' style='background:#1e293b; border-left:4px solid #38bdf8; padding:16px; border-radius:6px; margin:20px 0;'><h4 style='margin:0 0 10px;'>Table of Contents</h4><ul style='margin:0; padding-left:20px;'>";
        foreach ($matches as $match) {
            $title = strip_tags($match[2]);
            $slug = preg_replace('/[^a-z0-9]+/i', '-', strtolower($title));
            $toc .= "<li><a href='#{$slug}' style='color:#38bdf8; text-decoration:none;'>{$title}</a></li>";
        }
        $toc .= "</ul></nav>\n";
        return $toc . $content;
    }
    return $content;
});
