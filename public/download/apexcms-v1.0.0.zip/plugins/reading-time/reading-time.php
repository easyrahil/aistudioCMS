<?php
declare(strict_types=1);

use Apex\Core\Hook;

Hook::addFilter('the_content', function(string $content, array $post) {
    $wordCount = str_word_count(strip_tags($content));
    $minutes = max(1, (int)ceil($wordCount / 200));
    $badge = "<div class='reading-time-badge' style='display:inline-flex; align-items:center; gap:6px; background:#1e293b; color:#38bdf8; padding:4px 10px; border-radius:6px; font-size:12px; margin-bottom:16px;'>⏱️ {$minutes} min read ({$wordCount} words)</div>\n";
    return $badge . $content;
});
