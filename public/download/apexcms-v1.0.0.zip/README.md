# ApexCMS - Full-Stack Production CMS & E-Commerce

ApexCMS is an ultra-fast, zero-bloat, production-grade custom Content Management System and toggleable E-Commerce platform built in modern PHP 8.2+ with PDO prepared statements, semantic HTML5, vanilla JavaScript, and automated technical SEO engine.

## Key Features
- **Modern PHP 8.2+ Architecture**: Clean MVC, front controller (`public/index.php`), PSR-4 autoloader, and Hook system (Actions & Filters).
- **Toggleable Shop Module**: Toggle off via `Settings > Shop > Enable shop` to run as a pure high-performance blog (all shop routes return 404, shop blocks & cart are hidden).
- **Drag-and-Drop Homepage Block Builder**: Hero, Featured Posts, Shop Grid, Image+Text, CTA, FAQ, Testimonials, Newsletter, and Custom Code blocks.
- **Automated Technical SEO Engine**: Live Google SERP snippet preview, character limits, automated XML sitemaps, robots.txt generator, OpenGraph/Twitter Cards, and Schema.org JSON-LD.
- **Built-in Security**: Math in numbers + words captcha (`seven + 4 = ?`), Argon2id password hashing, CSRF tokens, strict HTML sanitization, rate limiting, and session fixation protection.
- **100/100 Core Web Vitals**: Inlined critical CSS, zero layout shift (CLS = 0), responsive WebP/AVIF generation, and file-based full-page caching.

## Web Installation
1. Upload ApexCMS to your web server document root pointing to `/public`.
2. Open your browser and navigate to `http://your-domain.com/install`.
3. Follow the 3-step wizard to test server requirements, configure MySQL/MariaDB or SQLite database, and create your administrator credentials.
4. Upon successful setup, the installer automatically writes `config.php` and creates `install/install.lock` to secure itself against unauthorized execution.

## Apache Configuration (.htaccess)
```apache
<IfModule mod_rewrite.c>
    RewriteEngine On
    RewriteCond %{REQUEST_FILENAME} !-f
    RewriteCond %{REQUEST_FILENAME} !-d
    RewriteRule ^(.*)$ index.php [QSA,L]
</IfModule>
```

## Nginx Configuration (nginx.conf)
```nginx
server {
    listen 80;
    server_name your-domain.com;
    root /var/www/apexcms/public;
    index index.php index.html;

    location / {
        try_files $uri $uri/ /index.php?$query_string;
    }

    location ~ \\.php$ {
        fastcgi_pass unix:/var/run/php/php8.2-fpm.sock;
        fastcgi_index index.php;
        fastcgi_param SCRIPT_FILENAME $realpath_root$fastcgi_script_name;
        include fastcgi_params;
    }

    location ^~ /storage/ {
        deny all;
    }
}
```

## Scheduled Tasks (Cron)
```cron
* * * * * cd /var/www/apexcms && php cron.php >> /var/log/apexcms_cron.log 2>&1
```

## Theme & Plugin ("Tools") Development
- Create a directory in `/themes/{your-theme}` with a `theme.json` manifest.
- Create plugins in `/plugins/{your-tool}` with `tool.json` and hook into core filters with `Hook::addFilter('the_content', ...)` or actions with `Hook::addAction('app_init', ...)`.

## License
MIT License. Built for enterprise publishing and high-speed e-commerce.
