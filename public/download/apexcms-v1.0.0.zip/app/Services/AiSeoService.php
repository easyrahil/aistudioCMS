<?php
declare(strict_types=1);

namespace Apex\Services;

use Apex\Models\Setting;

class AiSeoService
{
    public static function optimize(string $title, string $content, string $region = 'Global'): array
    {
        $cleanTitle = trim($title);
        return [
            'seo' => [
                'title'       => "{$cleanTitle} - Production Guide | ApexCMS",
                'description' => "Discover architecture and verified insights into {$cleanTitle}. Optimized for top search engine visibility and Core Web Vitals.",
                'keyword'     => strtolower(implode(' ', array_slice(explode(' ', $cleanTitle), 0, 3)))
            ],
            'geo' => [
                'region' => $region,
                'city'   => 'San Francisco & London',
                'lat'    => '37.7749',
                'lng'    => '-122.4194'
            ],
            'aeo' => [
                'direct_answer' => "{$cleanTitle} is a modern architectural paradigm engineered to deliver high reliability, zero layout shifts, and deterministic performance.",
                'key_takeaways' => [
                  'Sub-25ms TTFB via static full-page edge caching.',
                  'Zero layout shift (CLS=0) with reserved dimensions.',
                  'Direct citation capability for AI answer engines (Perplexity, SGE).'
                ]
            ]
        ];
    }
}
