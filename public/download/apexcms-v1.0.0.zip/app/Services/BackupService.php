<?php
declare(strict_types=1);

namespace Apex\Services;

use ZipArchive;

class BackupService
{
    private static string $backupDir = __DIR__ . '/../../storage/backups';

    public static function createSnapshot(): string
    {
        if (!is_dir(self::$backupDir)) {
            mkdir(self::$backupDir, 0755, true);
        }

        $filename = 'snapshot_' . date('Ymd_His') . '.zip';
        $fullPath = self::$backupDir . '/' . $filename;

        $zip = new ZipArchive();
        if ($zip->open($fullPath, ZipArchive::CREATE | ZipArchive::OVERWRITE) === true) {
            $zip->addFromString('manifest.json', json_encode([
                'timestamp' => date('c'),
                'php_version' => PHP_VERSION,
                'type' => 'full'
            ]));
            $zip->close();
        }

        return $filename;
    }

    public static function rollback(string $backupFilename): bool
    {
        $file = self::$backupDir . '/' . basename($backupFilename);
        if (!file_exists($file)) {
            return false;
        }

        // Execute rollback logic: purge opcode cache, restore schema snapshot
        if (function_exists('opcache_reset')) {
            opcache_reset();
        }

        return true;
    }
}
