<?php
declare(strict_types=1);

namespace Apex\Services;

use Apex\Models\Setting;

class SeoService
{
    public static function renderMeta(array $item, string $type = 'website'): string
    {
        $siteName = Setting::get('site_name', 'ApexCMS');
        $title = !empty($item['seo_title']) ? $item['seo_title'] : ($item['title'] ?? $siteName);
        $desc = !empty($item['seo_description']) ? $item['seo_description'] : Setting::get('site_tagline', 'Modern high-performance CMS');
        $canonical = !empty($item['seo_canonical']) ? $item['seo_canonical'] : ($item['url'] ?? '');
        $robots = !empty($item['seo_robots']) ? $item['seo_robots'] : 'index, follow';
        $image = !empty($item['featured_image']) ? $item['featured_image'] : '/assets/img/og-default.jpg';

        $html = "<!-- ApexCMS Advanced Technical SEO Engine -->\n";
        $html .= "<title>" . htmlspecialchars($title, ENT_QUOTES) . " | " . htmlspecialchars($siteName, ENT_QUOTES) . "</title>\n";
        $html .= "<meta name=\"description\" content=\"" . htmlspecialchars($desc, ENT_QUOTES) . "\">\n";
        $html .= "<meta name=\"robots\" content=\"{$robots}\">\n";
        if ($canonical) {
            $html .= "<link rel=\"canonical\" href=\"{$canonical}\">\n";
        }

        // Open Graph
        $html .= "<meta property=\"og:type\" content=\"{$type}\">\n";
        $html .= "<meta property=\"og:title\" content=\"" . htmlspecialchars($title, ENT_QUOTES) . "\">\n";
        $html .= "<meta property=\"og:description\" content=\"" . htmlspecialchars($desc, ENT_QUOTES) . "\">\n";
        $html .= "<meta property=\"og:url\" content=\"{$canonical}\">\n";
        $html .= "<meta property=\"og:site_name\" content=\"" . htmlspecialchars($siteName, ENT_QUOTES) . "\">\n";
        $html .= "<meta property=\"og:image\" content=\"{$image}\">\n";

        // Twitter Card
        $html .= "<meta name=\"twitter:card\" content=\"summary_large_image\">\n";
        $html .= "<meta name=\"twitter:title\" content=\"" . htmlspecialchars($title, ENT_QUOTES) . "\">\n";
        $html .= "<meta name=\"twitter:description\" content=\"" . htmlspecialchars($desc, ENT_QUOTES) . "\">\n";
        $html .= "<meta name=\"twitter:image\" content=\"{$image}\">\n";

        return $html;
    }

    public static function generateJsonLd(array $item, string $schemaType = 'Article'): string
    {
        $siteUrl = Setting::get('site_url', 'http://localhost');
        $siteName = Setting::get('site_name', 'ApexCMS');

        $data = [
            '@context' => 'https://schema.org',
            '@type' => $schemaType,
            'mainEntityOfPage' => [
                '@type' => 'WebPage',
                '@id' => $item['url'] ?? $siteUrl
            ],
            'headline' => $item['title'] ?? $siteName,
            'description' => $item['seo_description'] ?? $item['excerpt'] ?? '',
            'image' => $item['featured_image'] ?? "{$siteUrl}/assets/img/og-default.jpg",
            'publisher' => [
                '@type' => 'Organization',
                'name' => $siteName,
                'logo' => [
                    '@type' => 'ImageObject',
                    'url' => "{$siteUrl}/assets/img/logo.png"
                ]
            ]
        ];

        return '<script type="application/ld+json">' . json_encode($data, JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT) . '</script>';
    }
}
