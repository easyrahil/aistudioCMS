<?php
declare(strict_types=1);

namespace Apex\Services;

use Apex\Core\Session;

class CaptchaService
{
    private static array $numberWords = [
        0 => 'zero', 1 => 'one', 2 => 'two', 3 => 'three', 4 => 'four',
        5 => 'five', 6 => 'six', 7 => 'seven', 8 => 'eight', 9 => 'nine'
    ];

    public static function generate(): array
    {
        Session::start();
        $num1 = random_int(1, 9);
        $num2 = random_int(1, 9);
        $op = random_int(0, 1) === 0 ? '+' : '*';

        $answer = $op === '+' ? ($num1 + $num2) : ($num1 * $num2);
        $opWord = $op === '+' ? 'plus' : 'times';

        // Mix words and numbers: e.g. "seven + 4" or "3 plus five"
        $mixMode = random_int(1, 3);
        if ($mixMode === 1) {
            $question = self::$numberWords[$num1] . " " . $op . " " . $num2 . " = ?";
        } elseif ($mixMode === 2) {
            $question = $num1 . " " . $opWord . " " . self::$numberWords[$num2] . " = ?";
        } else {
            $question = self::$numberWords[$num1] . " " . $opWord . " " . self::$numberWords[$num2] . " = ?";
        }

        $token = bin2hex(random_bytes(16));
        $_SESSION['_captcha'][$token] = [
            'answer' => $answer,
            'expires' => time() + 300 // 5 minutes
        ];

        return [
            'token' => $token,
            'question' => $question
        ];
    }

    public static function validate(string $token, string $userAnswer): bool
    {
        Session::start();
        if (empty($_SESSION['_captcha'][$token])) {
            return false;
        }

        $data = $_SESSION['_captcha'][$token];
        unset($_SESSION['_captcha'][$token]); // Single-use!

        if (time() > $data['expires']) {
            return false;
        }

        return (int)trim($userAnswer) === (int)$data['answer'];
    }
}
