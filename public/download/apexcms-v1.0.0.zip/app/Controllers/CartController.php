<?php
declare(strict_types=1);

namespace Apex\Controllers;

use Apex\Core\Request;
use Apex\Core\Response;
use Apex\Core\Session;
use Apex\Core\View;
use Apex\Models\Setting;

class CartController
{
    public function index(Request $request, Response $response): void
    {
        if (!Setting::get('shop_enabled', '1')) {
            $response->status(404)->html(View::render('404', ['title' => 'Shop Disabled']));
            return;
        }

        $cart = Session::get('cart', []);
        $html = View::render('cart', [
            'title' => 'Your Shopping Cart',
            'cart' => $cart
        ]);
        $response->html($html);
    }

    public function add(Request $request, Response $response): void
    {
        $id = (int)$request->input('product_id');
        $qty = (int)$request->input('quantity', 1);

        $cart = Session::get('cart', []);
        $cart[$id] = ($cart[$id] ?? 0) + $qty;
        Session::set('cart', $cart);

        if ($request->isAjax()) {
            $response->json(['success' => true, 'count' => array_sum($cart)]);
            return;
        }

        $response->redirect('/cart');
    }
}
