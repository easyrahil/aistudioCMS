<?php
declare(strict_types=1);

namespace Apex\Controllers;

use Apex\Core\Request;
use Apex\Core\Response;
use Apex\Core\View;
use Apex\Models\Page;

class PageController
{
    public function show(Request $request, Response $response, array $params): void
    {
        $slug = $params['slug'] ?? '';
        $page = Page::findBySlug($slug);

        if (!$page) {
            $response->status(404)->html(View::render('404', ['title' => 'Page Not Found']));
            return;
        }

        $html = View::render('page', [
            'page' => $page,
            'title' => $page['title']
        ]);

        $response->html($html);
    }
}
