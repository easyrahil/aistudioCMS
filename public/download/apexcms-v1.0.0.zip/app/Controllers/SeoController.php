<?php
declare(strict_types=1);

namespace Apex\Controllers;

use Apex\Core\Request;
use Apex\Core\Response;
use Apex\Models\Post;
use Apex\Models\Product;
use Apex\Models\Setting;

class SeoController
{
    public function sitemap(Request $request, Response $response): void
    {
        $siteUrl = Setting::get('site_url', 'http://localhost');
        $posts = Post::getPublished(100);
        $products = Setting::get('shop_enabled', '1') ? Product::getPublished(100) : [];

        $xml = '<?xml version="1.0" encoding="UTF-8"?>\n';
        $xml .= '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n';

        $xml .= "  <url><loc>{$siteUrl}/</loc><priority>1.0</priority><changefreq>daily</changefreq></url>\n";

        foreach ($posts as $p) {
            $xml .= "  <url><loc>{$siteUrl}/post/{$p['slug']}</loc><priority>0.8</priority><changefreq>weekly</changefreq></url>\n";
        }

        foreach ($products as $pr) {
            $xml .= "  <url><loc>{$siteUrl}/product/{$pr['slug']}</loc><priority>0.7</priority><changefreq>weekly</changefreq></url>\n";
        }

        $xml .= '</urlset>';

        $response->header('Content-Type', 'application/xml; charset=utf-8')->html($xml);
    }

    public function robots(Request $request, Response $response): void
    {
        $siteUrl = Setting::get('site_url', 'http://localhost');
        $txt = "User-agent: *\n";
        $txt .= "Allow: /\n";
        $txt .= "Disallow: /admin/\n";
        $txt .= "Disallow: /storage/\n";
        $txt .= "Disallow: /cart\n";
        $txt .= "Disallow: /checkout\n";
        $txt .= "Sitemap: {$siteUrl}/sitemap.xml\n";

        $response->header('Content-Type', 'text/plain; charset=utf-8')->html($txt);
    }

    public function feed(Request $request, Response $response): void
    {
        $siteName = Setting::get('site_name', 'ApexCMS');
        $siteUrl = Setting::get('site_url', 'http://localhost');
        $posts = Post::getPublished(20);

        $rss = '<?xml version="1.0" encoding="UTF-8"?>\n';
        $rss .= '<rss version="2.0">\n<channel>\n';
        $rss .= "<title>{$siteName}</title>\n";
        $rss .= "<link>{$siteUrl}</link>\n";
        $rss .= "<description>Latest essays, dispatches, and updates</description>\n";

        foreach ($posts as $p) {
            $rss .= "<item>\n";
            $rss .= "<title>" . htmlspecialchars($p['title']) . "</title>\n";
            $rss .= "<link>{$siteUrl}/post/{$p['slug']}</link>\n";
            $rss .= "<description>" . htmlspecialchars($p['excerpt'] ?? '') . "</description>\n";
            $rss .= "</item>\n";
        }

        $rss .= '</channel>\n</rss>';
        $response->header('Content-Type', 'application/rss+xml; charset=utf-8')->html($rss);
    }
}
