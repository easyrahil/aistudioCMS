<?php
declare(strict_types=1);

namespace Apex\Controllers;

use Apex\Core\Request;
use Apex\Core\Response;
use Apex\Core\View;
use Apex\Core\Hook;
use Apex\Models\Post;

class PostController
{
    public function show(Request $request, Response $response, array $params): void
    {
        $slug = $params['slug'] ?? '';
        $post = Post::findBySlug($slug, 'post');

        if (!$post) {
            $response->status(404)->html(View::render('404', ['title' => 'Article Not Found']));
            return;
        }

        // Apply hook filters from plugins/tools (e.g. Reading Time, Table of Contents)
        $post['body'] = Hook::applyFilter('the_content', $post['body'], $post);

        $html = View::render('single', [
            'post' => $post,
            'title' => $post['title']
        ]);

        $response->html($html);
    }
}
