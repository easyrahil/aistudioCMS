<?php
declare(strict_types=1);

namespace Apex\Controllers;

use Apex\Core\Request;
use Apex\Core\Response;
use Apex\Core\View;
use Apex\Models\Post;
use Apex\Models\Product;
use Apex\Models\Setting;

class HomeController
{
    public function index(Request $request, Response $response): void
    {
        $shopEnabled = (bool)Setting::get('shop_enabled', '1');
        $blocksJson = Setting::get('homepage_blocks', '[]');
        $blocks = json_decode($blocksJson, true) ?: [];

        $posts = Post::getPublished(4);
        $products = $shopEnabled ? Product::getPublished(4) : [];

        $html = View::render('index', [
            'title' => Setting::get('site_name', 'ApexCMS'),
            'blocks' => $blocks,
            'posts' => $posts,
            'products' => $products,
            'shopEnabled' => $shopEnabled
        ]);

        $response->html($html);
    }
}
