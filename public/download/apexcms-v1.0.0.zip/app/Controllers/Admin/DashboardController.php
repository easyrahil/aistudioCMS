<?php
declare(strict_types=1);

namespace Apex\Controllers\Admin;

use Apex\Core\Request;
use Apex\Core\Response;
use Apex\Core\View;
use Apex\Models\Post;
use Apex\Models\Product;
use Apex\Models\Setting;

class DashboardController
{
    public function index(Request $request, Response $response): void
    {
        $data = [
            'title' => 'ApexCMS Executive Dashboard',
            'postCount' => Post::countPublished(),
            'shopEnabled' => (bool)Setting::get('shop_enabled', '1'),
            'phpVersion' => PHP_VERSION,
            'cacheTtl' => Setting::get('cache_ttl', '3600'),
        ];

        $html = View::render('admin_dashboard', $data);
        $response->html($html);
    }
}
