<?php
declare(strict_types=1);

namespace Apex\Controllers;

use Apex\Core\Request;
use Apex\Core\Response;
use Apex\Core\View;
use Apex\Models\Product;
use Apex\Models\Setting;

class ShopController
{
    public function index(Request $request, Response $response): void
    {
        if (!Setting::get('shop_enabled', '1')) {
            $response->status(404)->html(View::render('404', ['title' => 'Shop Disabled']));
            return;
        }

        $products = Product::getPublished(20);
        $html = View::render('shop', [
            'title' => 'Catalog & Shop | ' . Setting::get('site_name', 'ApexCMS'),
            'products' => $products
        ]);

        $response->html($html);
    }

    public function product(Request $request, Response $response, array $params): void
    {
        if (!Setting::get('shop_enabled', '1')) {
            $response->status(404)->html(View::render('404', ['title' => 'Shop Disabled']));
            return;
        }

        $slug = $params['slug'] ?? '';
        $product = Product::findBySlug($slug);

        if (!$product) {
            $response->status(404)->html(View::render('404', ['title' => 'Product Not Found']));
            return;
        }

        $html = View::render('product', [
            'title' => $product['title'],
            'product' => $product
        ]);

        $response->html($html);
    }
}
