<?php
declare(strict_types=1);

namespace Apex\Controllers;

use Apex\Core\Request;
use Apex\Core\Response;
use Apex\Core\Session;
use Apex\Core\View;
use Apex\Models\Setting;

class CheckoutController
{
    public function index(Request $request, Response $response): void
    {
        if (!Setting::get('shop_enabled', '1')) {
            $response->status(404)->html(View::render('404', ['title' => 'Shop Disabled']));
            return;
        }

        $cart = Session::get('cart', []);
        $html = View::render('checkout', [
            'title' => 'Secure Checkout',
            'cart' => $cart
        ]);
        $response->html($html);
    }

    public function process(Request $request, Response $response): void
    {
        // Tokenized order placement
        Session::set('cart', []);
        $response->redirect('/checkout?success=1');
    }
}
