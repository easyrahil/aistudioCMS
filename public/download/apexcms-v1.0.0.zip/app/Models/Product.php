<?php
declare(strict_types=1);

namespace Apex\Models;

use Apex\Core\Database;

class Product
{
    public static function findBySlug(string $slug): ?array
    {
        return Database::queryOne(
            "SELECT * FROM products WHERE slug = :slug AND status = 'published' LIMIT 1",
            ['slug' => $slug]
        );
    }

    public static function getPublished(int $limit = 12, int $offset = 0): array
    {
        return Database::query(
            "SELECT * FROM products WHERE status = 'published' ORDER BY created_at DESC LIMIT :limit OFFSET :offset",
            ['limit' => $limit, 'offset' => $offset]
        );
    }
}
