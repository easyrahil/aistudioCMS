<?php
declare(strict_types=1);

namespace Apex\Models;

use Apex\Core\Database;

class Post
{
    public static function findBySlug(string $slug, string $type = 'post'): ?array
    {
        return Database::queryOne(
            "SELECT p.*, u.username as author_name FROM posts p 
             LEFT JOIN users u ON u.id = p.author_id 
             WHERE p.slug = :slug AND p.type = :type AND p.status = 'published' LIMIT 1",
            ['slug' => $slug, 'type' => $type]
        );
    }

    public static function getPublished(int $limit = 10, int $offset = 0): array
    {
        return Database::query(
            "SELECT p.*, u.username as author_name FROM posts p 
             LEFT JOIN users u ON u.id = p.author_id 
             WHERE p.type = 'post' AND p.status = 'published' 
             ORDER BY p.published_at DESC LIMIT :limit OFFSET :offset",
            ['limit' => $limit, 'offset' => $offset]
        );
    }

    public static function countPublished(): int
    {
        $res = Database::queryOne("SELECT COUNT(*) as cnt FROM posts WHERE type = 'post' AND status = 'published'");
        return (int)($res['cnt'] ?? 0);
    }
}
