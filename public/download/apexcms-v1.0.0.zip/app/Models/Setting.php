<?php
declare(strict_types=1);

namespace Apex\Models;

use Apex\Core\Database;

class Setting
{
    private static array $cache = [];

    public static function get(string $key, mixed $default = null): mixed
    {
        if (isset(self::$cache[$key])) {
            return self::$cache[$key];
        }

        try {
            $row = Database::queryOne("SELECT value FROM settings WHERE `key` = :key", ['key' => $key]);
            if ($row) {
                self::$cache[$key] = $row['value'];
                return $row['value'];
            }
        } catch (\Exception $e) {
            // DB not yet installed or table missing
        }

        return $default;
    }

    public static function set(string $key, mixed $value): bool
    {
        self::$cache[$key] = $value;
        return Database::execute(
            "INSERT INTO settings (`key`, `value`) VALUES (:key, :val) ON DUPLICATE KEY UPDATE `value` = :val2",
            ['key' => $key, 'val' => (string)$value, 'val2' => (string)$value]
        );
    }
}
