<?php
declare(strict_types=1);

namespace Apex\Models;

use Apex\Core\Database;
use Apex\Core\Security;

class User
{
    public static function findByEmail(string $email): ?array
    {
        return Database::queryOne("SELECT * FROM users WHERE email = :email LIMIT 1", ['email' => $email]);
    }

    public static function create(string $username, string $email, string $password, string $role = 'user'): int
    {
        $hash = Security::hashPassword($password);
        Database::execute(
            "INSERT INTO users (username, email, password_hash, role, status, created_at) VALUES (:u, :e, :p, :r, 'active', NOW())",
            ['u' => $username, 'e' => $email, 'p' => $hash, 'r' => $role]
        );
        return (int)Database::lastInsertId();
    }
}
