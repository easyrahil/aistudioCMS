<?php
declare(strict_types=1);

namespace Apex\Models;

use Apex\Core\Database;

class Page
{
    public static function findBySlug(string $slug): ?array
    {
        return Database::queryOne(
            "SELECT * FROM posts WHERE slug = :slug AND type = 'page' AND status = 'published' LIMIT 1",
            ['slug' => $slug]
        );
    }

    public static function getAll(): array
    {
        return Database::query("SELECT * FROM posts WHERE type = 'page' ORDER BY created_at DESC");
    }
}
