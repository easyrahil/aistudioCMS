<?php
declare(strict_types=1);

if (file_exists(__DIR__ . '/install.lock')) {
    http_response_code(403);
    echo '<!DOCTYPE html><html><body style="font-family:sans-serif;text-align:center;padding:50px;"><h2>ApexCMS Installer is Locked</h2><p>The installer has already been completed and locked for security. To re-run, remove <code>install/install.lock</code>.</p></body></html>';
    exit;
}

$step = (int)($_GET['step'] ?? 1);
$errors = [];
$success = false;

// Step 1: Requirements Check
$reqs = [
    'PHP 8.2+' => version_compare(PHP_VERSION, '8.2.0', '>='),
    'PDO Extension' => extension_loaded('pdo'),
    'mbstring Extension' => extension_loaded('mbstring'),
    'XML Extension' => extension_loaded('xml'),
    'JSON Extension' => extension_loaded('json'),
    'Storage Writable' => is_writable(__DIR__ . '/../storage') || @mkdir(__DIR__ . '/../storage', 0755, true),
];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $step === 3) {
    // Process installation
    $dbHost = $_POST['db_host'] ?? '127.0.0.1';
    $dbPort = (int)($_POST['db_port'] ?? 3306);
    $dbName = $_POST['db_name'] ?? 'apexcms';
    $dbUser = $_POST['db_user'] ?? 'root';
    $dbPass = $_POST['db_pass'] ?? '';
    $driver = $_POST['db_driver'] ?? 'mysql';

    $adminUser = trim($_POST['admin_user'] ?? 'admin');
    $adminEmail = trim($_POST['admin_email'] ?? 'admin@example.com');
    $adminPass = $_POST['admin_pass'] ?? '';

    if (empty($adminPass) || strlen($adminPass) < 8) {
        $errors[] = "Admin password must be at least 8 characters long.";
    }

    if (empty($errors)) {
        try {
            if ($driver === 'sqlite') {
                $dsn = 'sqlite:' . __DIR__ . '/../storage/database.sqlite';
                $pdo = new PDO($dsn);
            } else {
                $dsn = "mysql:host={$dbHost};port={$dbPort};dbname={$dbName};charset=utf8mb4";
                $pdo = new PDO($dsn, $dbUser, $dbPass, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
            }

            // Run Schema
            $schema = file_get_contents(__DIR__ . '/../database/schema.sql');
            $pdo->exec($schema);

            // Run Seeds
            $seeds = file_get_contents(__DIR__ . '/../database/seeds.sql');
            $pdo->exec($seeds);

            // Create Admin
            $passHash = password_hash($adminPass, PASSWORD_ARGON2ID);
            $stmt = $pdo->prepare("INSERT INTO users (username, email, password_hash, role, status, created_at) VALUES (?, ?, ?, 'admin', 'active', NOW())");
            $stmt->execute([$adminUser, $adminEmail, $passHash]);

            // Write config.php
            $configContent = "<?php\nreturn [\n    'database' => [\n        'driver' => '{$driver}',\n        'host' => '{$dbHost}',\n        'port' => {$dbPort},\n        'database' => '{$dbName}',\n        'username' => '{$dbUser}',\n        'password' => '{$dbPass}',\n    ]\n];\n";
            file_put_contents(__DIR__ . '/../config.php', $configContent);

            // Lock Installer
            file_put_contents(__DIR__ . '/install.lock', 'Installed on ' . date('c'));
            $success = true;

        } catch (Exception $e) {
            $errors[] = "Installation Error: " . $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>ApexCMS Web Installer</title>
    <style>
        body { font-family: system-ui, -apple-system, sans-serif; background: #0f172a; color: #f8fafc; margin: 0; padding: 40px 20px; }
        .container { max-width: 640px; margin: 0 auto; background: #1e293b; border-radius: 12px; padding: 32px; box-shadow: 0 10px 25px rgba(0,0,0,0.4); border: 1px solid #334155; }
        h1 { color: #38bdf8; margin-top: 0; font-size: 24px; }
        .badge { padding: 4px 10px; border-radius: 6px; font-weight: bold; font-size: 13px; }
        .badge-pass { background: #059669; color: white; }
        .badge-fail { background: #dc2626; color: white; }
        .req-item { display: flex; justify-content: space-between; padding: 10px 0; border-bottom: 1px solid #334155; }
        .btn { display: inline-block; background: #2563eb; color: white; padding: 12px 24px; border-radius: 8px; text-decoration: none; font-weight: 600; border: none; cursor: pointer; }
        .btn:hover { background: #1d4ed8; }
        .form-group { margin-bottom: 16px; }
        label { display: block; margin-bottom: 6px; font-weight: 500; font-size: 14px; }
        input, select { width: 100%; box-sizing: border-box; padding: 10px 12px; background: #0f172a; border: 1px solid #475569; border-radius: 6px; color: white; }
        .error-box { background: #ef444420; border: 1px solid #ef4444; color: #fca5a5; padding: 12px; border-radius: 6px; margin-bottom: 16px; }
        .success-box { background: #10b98120; border: 1px solid #10b981; color: #6ee7b7; padding: 16px; border-radius: 6px; text-align: center; }
    </style>
</head>
<body>
<div class="container">
    <h1>🚀 ApexCMS Setup Wizard</h1>
    <?php if ($success): ?>
        <div class="success-box">
            <h2>🎉 ApexCMS Successfully Installed!</h2>
            <p>The installer has locked itself for security (<code>install/install.lock</code> created).</p>
            <p><a href="/admin" class="btn">Go to Admin Panel</a> <a href="/" class="btn" style="background:#475569;">Visit Website</a></p>
        </div>
    <?php else: ?>
        <?php if (!empty($errors)): ?>
            <div class="error-box">
                <?php foreach ($errors as $err): ?>
                    <p><?= htmlspecialchars($err) ?></p>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>

        <?php if ($step === 1): ?>
            <h3>Step 1: System Verification</h3>
            <div style="margin: 20px 0;">
                <?php foreach ($reqs as $name => $ok): ?>
                    <div class="req-item">
                        <span><?= $name ?></span>
                        <span class="badge <?= $ok ? 'badge-pass' : 'badge-fail' ?>"><?= $ok ? 'PASSED' : 'FAILED' ?></span>
                    </div>
                <?php endforeach; ?>
            </div>
            <a href="?step=2" class="btn">Continue to Configuration &rarr;</a>

        <?php elseif ($step === 2 || $step === 3): ?>
            <form method="POST" action="?step=3">
                <h3>Step 2: Database Connection</h3>
                <div class="form-group">
                    <label>Database Driver</label>
                    <select name="db_driver">
                        <option value="mysql">MySQL / MariaDB (utf8mb4)</option>
                        <option value="sqlite">SQLite</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>Database Host</label>
                    <input type="text" name="db_host" value="127.0.0.1">
                </div>
                <div class="form-group">
                    <label>Database Name</label>
                    <input type="text" name="db_name" value="apexcms">
                </div>
                <div class="form-group">
                    <label>Database User</label>
                    <input type="text" name="db_user" value="root">
                </div>
                <div class="form-group">
                    <label>Database Password</label>
                    <input type="password" name="db_pass" value="">
                </div>

                <h3 style="margin-top:24px;">Step 3: Administrator Account</h3>
                <div class="form-group">
                    <label>Admin Username</label>
                    <input type="text" name="admin_user" value="admin" required>
                </div>
                <div class="form-group">
                    <label>Admin Email</label>
                    <input type="email" name="admin_email" value="admin@example.com" required>
                </div>
                <div class="form-group">
                    <label>Admin Password (Argon2id)</label>
                    <input type="password" name="admin_pass" value="AdminPass123!" required>
                </div>

                <button type="submit" class="btn" style="width: 100%; margin-top: 16px;">Install ApexCMS Now &rarr;</button>
            </form>
        <?php endif; ?>
    <?php endif; ?>
</div>
</body>
</html>
