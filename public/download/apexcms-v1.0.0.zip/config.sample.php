<?php
declare(strict_types=1);

return [
    'app' => [
        'name'        => 'ApexCMS',
        'url'         => 'http://localhost',
        'env'         => 'production', // 'development' or 'production'
        'debug'       => false,
        'timezone'    => 'UTC',
        'locale'      => 'en',
        'key'         => 'base64:GENERATE_A_RANDOM_SECRET_KEY_HERE',
    ],
    'database' => [
        'driver'   => 'mysql', // 'mysql' or 'sqlite'
        'host'     => '127.0.0.1',
        'port'     => 3306,
        'database' => 'apexcms',
        'username' => 'root',
        'password' => '',
        'charset'  => 'utf8mb4',
        'collation'=> 'utf8mb4_unicode_ci',
        'prefix'   => '',
    ],
    'security' => [
        'admin_path' => 'admin',
        'argon_memory_cost' => 65536,
        'argon_time_cost'   => 4,
        'argon_threads'     => 1,
    ]
];
