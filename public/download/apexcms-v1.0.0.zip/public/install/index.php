<?php
declare(strict_types=1);

/**
 * ApexCMS Installer Fallback Bridge
 * Active when Apache DocumentRoot points directly to public/
 */
if (file_exists(__DIR__ . '/../../install/index.php')) {
    require_once __DIR__ . '/../../install/index.php';
} else {
    http_response_code(404);
    echo '<!DOCTYPE html><html><body style="font-family:sans-serif;text-align:center;padding:50px;"><h2>Installer Not Found</h2><p>Could not locate the <code>install/index.php</code> script.</p></body></html>';
}
