<?php
declare(strict_types=1);

/**
 * ApexCMS Admin Bridge for Public DocumentRoot
 */
$_SERVER['REQUEST_URI'] = '/admin' . (isset($_SERVER['QUERY_STRING']) && $_SERVER['QUERY_STRING'] !== '' ? '?' . $_SERVER['QUERY_STRING'] : '');
require_once __DIR__ . '/../index.php';
