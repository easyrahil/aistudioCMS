<?php
declare(strict_types=1);

// ApexCMS Front Controller
// Check installer
if (!file_exists(__DIR__ . '/../install/install.lock')) {
    if (file_exists(__DIR__ . '/../install/index.php')) {
        header("Location: /install/");
        exit;
    }
}

require_once __DIR__ . '/../core/Autoloader.php';
\Apex\Core\Autoloader::register();

$app = new \Apex\Core\App();
$router = $app->router();

// Public Routes
$router->get('/', [\Apex\Controllers\HomeController::class, 'index']);
$router->get('/post/{slug}', [\Apex\Controllers\PostController::class, 'show']);
$router->get('/page/{slug}', [\Apex\Controllers\PageController::class, 'show']);

// Shop Routes (Conditionally enabled)
$router->get('/shop', [\Apex\Controllers\ShopController::class, 'index']);
$router->get('/product/{slug}', [\Apex\Controllers\ShopController::class, 'product']);
$router->get('/cart', [\Apex\Controllers\CartController::class, 'index']);
$router->post('/cart/add', [\Apex\Controllers\CartController::class, 'add']);
$router->get('/checkout', [\Apex\Controllers\CheckoutController::class, 'index']);
$router->post('/checkout', [\Apex\Controllers\CheckoutController::class, 'process']);

// SEO & Feeds
$router->get('/sitemap.xml', [\Apex\Controllers\SeoController::class, 'sitemap']);
$router->get('/robots.txt', [\Apex\Controllers\SeoController::class, 'robots']);
$router->get('/feed', [\Apex\Controllers\SeoController::class, 'feed']);

// Admin Route Group
$router->get('/admin', [\Apex\Controllers\Admin\DashboardController::class, 'index']);
$router->get('/admin/{section}', [\Apex\Controllers\Admin\DashboardController::class, 'index']);
$router->post('/admin/{section}', [\Apex\Controllers\Admin\DashboardController::class, 'index']);
$router->post('/admin/{section}/{action}', [\Apex\Controllers\Admin\DashboardController::class, 'index']);

$app->run();
