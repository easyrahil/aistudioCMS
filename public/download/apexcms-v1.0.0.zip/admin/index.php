<?php
declare(strict_types=1);

/**
 * ==============================================================================
 * ApexCMS Admin Suite Front Controller
 * ==============================================================================
 * Renders the executive admin suite cleanly without any Apache directory listings.
 */

// If installer is not completed, redirect to installer
if (!file_exists(__DIR__ . '/../install/install.lock')) {
    if (file_exists(__DIR__ . '/../install/index.php')) {
        header('Location: /install/');
        exit;
    }
}

// Database models & published article counts
$postCount = 6;
$shopEnabled = true;

if (file_exists(__DIR__ . '/../core/Autoloader.php')) {
    require_once __DIR__ . '/../core/Autoloader.php';
    \Apex\Core\Autoloader::register();
    try {
        if (class_exists(\Apex\Models\Post::class)) {
            $postCount = \Apex\Models\Post::countPublished();
        }
        if (class_exists(\Apex\Models\Setting::class)) {
            $shopEnabled = (bool)\Apex\Models\Setting::get('shop_enabled', '1');
        }
    } catch (\Throwable $e) {
        // Fallback gracefully
    }
}

// Forward to admin dashboard view
$title = 'ApexCMS Executive Dashboard';
require __DIR__ . '/views/admin_dashboard.php';
