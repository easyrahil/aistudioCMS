<?php
declare(strict_types=1);

namespace Apex\Core;

class View
{
    private static string $activeTheme = 'magazine';

    public static function setTheme(string $theme): void
    {
        self::$activeTheme = $theme;
    }

    public static function render(string $template, array $data = []): string
    {
        extract($data);
        $e = fn($str) => htmlspecialchars((string)$str, ENT_QUOTES, 'UTF-8');

        // 1. Check admin views directory first for admin templates
        if (str_starts_with($template, 'admin_') || $template === 'admin_dashboard') {
            $adminPath = __DIR__ . "/../admin/views/{$template}.php";
            if (file_exists($adminPath)) {
                ob_start();
                include $adminPath;
                return ob_get_clean();
            }
        }

        // 2. Check active theme directory
        $themePath = __DIR__ . "/../themes/" . self::$activeTheme . "/{$template}.php";
        if (file_exists($themePath)) {
            ob_start();
            include $themePath;
            return ob_get_clean();
        }

        // 3. Check magazine fallback theme
        $fallbackThemePath = __DIR__ . "/../themes/magazine/{$template}.php";
        if (file_exists($fallbackThemePath)) {
            ob_start();
            include $fallbackThemePath;
            return ob_get_clean();
        }

        // 4. Check admin views directory as general fallback
        $adminFallbackPath = __DIR__ . "/../admin/views/{$template}.php";
        if (file_exists($adminFallbackPath)) {
            ob_start();
            include $adminFallbackPath;
            return ob_get_clean();
        }

        return "<div style='font-family: sans-serif; padding: 24px; background: #fff0f0; border: 1px solid #ffcccc; border-radius: 8px; color: #900;'>Template '{$template}' not found. Checked: active theme, magazine theme, and admin views.</div>";
    }
}
