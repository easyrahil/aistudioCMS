<?php
declare(strict_types=1);

namespace Apex\Core;

class Router
{
    private array $routes = [];
    private array $namedRoutes = [];
    private array $middlewareGroups = [];

    public function add(string $method, string $pattern, mixed $handler, array $middleware = [], ?string $name = null): self
    {
        $pattern = '/' . trim($pattern, '/');
        $route = [
            'method'     => strtoupper($method),
            'pattern'    => $pattern,
            'handler'    => $handler,
            'middleware' => $middleware,
        ];

        $this->routes[] = $route;
        if ($name !== null) {
            $this->namedRoutes[$name] = $pattern;
        }
        return $this;
    }

    public function get(string $pattern, mixed $handler, array $middleware = [], ?string $name = null): self
    {
        return $this->add('GET', $pattern, $handler, $middleware, $name);
    }

    public function post(string $pattern, mixed $handler, array $middleware = [], ?string $name = null): self
    {
        return $this->add('POST', $pattern, $handler, $middleware, $name);
    }

    public function dispatch(Request $request, Response $response): void
    {
        $method = $request->method();
        $path   = $request->path();

        // 301 Trailing slash normalization
        if ($path !== '/' && str_ends_with($path, '/')) {
            $cleanUrl = rtrim($path, '/');
            $response->redirect($cleanUrl, 301);
            return;
        }

        foreach ($this->routes as $route) {
            if ($route['method'] !== $method && $route['method'] !== 'ANY') {
                continue;
            }

            $regex = preg_replace('#\{([a-zA-Z0-9_]+)\}#', '(?P<$1>[^/]+)', $route['pattern']);
            $regex = '#^' . $regex . '$#';

            if (preg_match($regex, $path, $matches)) {
                $params = array_filter($matches, 'is_string', ARRAY_FILTER_USE_KEY);

                // Run Middleware
                foreach ($route['middleware'] as $mwClass) {
                    $mw = new $mwClass();
                    $passed = $mw->handle($request, $response);
                    if (!$passed) {
                        return;
                    }
                }

                // Execute handler
                $handler = $route['handler'];
                if (is_callable($handler)) {
                    call_user_func($handler, $request, $response, $params);
                    return;
                }

                if (is_array($handler)) {
                    [$class, $action] = $handler;
                    $controller = new $class();
                    $controller->$action($request, $response, $params);
                    return;
                }
            }
        }

        // 404 Route
        $response->status(404)->html(View::render('404', ['title' => '404 - Page Not Found']));
    }
}
