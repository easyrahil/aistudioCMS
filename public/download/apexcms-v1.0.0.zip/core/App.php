<?php
declare(strict_types=1);

namespace Apex\Core;

class App
{
    private Router $router;
    private Request $request;
    private Response $response;

    public function __construct()
    {
        Autoloader::register();
        $this->router   = new Router();
        $this->request  = new Request();
        $this->response = new Response();
    }

    public function router(): Router
    {
        return $this->router;
    }

    public function run(): void
    {
        Hook::doAction('app_init');
        $this->router->dispatch($this->request, $this->response);
        Hook::doAction('app_finish');
    }
}
