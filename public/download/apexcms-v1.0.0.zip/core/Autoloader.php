<?php
declare(strict_types=1);

namespace Apex\Core;

class Autoloader
{
    private static array $prefixes = [
        'Apex\\Core\\' => __DIR__ . '/',
        'Apex\\'       => __DIR__ . '/../app/'
    ];

    public static function register(): void
    {
        spl_autoload_register([self::class, 'loadClass']);
    }

    public static function loadClass(string $class): bool
    {
        foreach (self::$prefixes as $prefix => $baseDir) {
            $len = strlen($prefix);
            if (strncmp($prefix, $class, $len) !== 0) {
                continue;
            }

            $relativeClass = substr($class, $len);
            $file = $baseDir . str_replace('\\', '/', $relativeClass) . '.php';

            if (file_exists($file)) {
                require_once $file;
                return true;
            }
        }
        return false;
    }
}
