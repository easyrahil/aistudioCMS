<?php
declare(strict_types=1);

namespace Apex\Core;

use PDO;
use PDOException;
use RuntimeException;

class Database
{
    private static ?PDO $instance = null;
    private static array $queryLog = [];

    public static function getInstance(?array $config = null): PDO
    {
        if (self::$instance === null) {
            if ($config === null) {
                $configFile = __DIR__ . '/../config.php';
                if (!file_exists($configFile)) {
                    throw new RuntimeException("Database configuration file not found. Please run installer at /install.");
                }
                $appConfig = require $configFile;
                $config = $appConfig['database'] ?? [];
            }

            $driver = $config['driver'] ?? 'mysql';

            try {
                if ($driver === 'sqlite') {
                    $dsn = 'sqlite:' . ($config['database'] ?? __DIR__ . '/../storage/database.sqlite');
                    self::$instance = new PDO($dsn);
                } else {
                    $host = $config['host'] ?? '127.0.0.1';
                    $port = $config['port'] ?? 3306;
                    $db   = $config['database'] ?? 'apexcms';
                    $charset = $config['charset'] ?? 'utf8mb4';
                    $dsn = "mysql:host={$host};port={$port};dbname={$db};charset={$charset}";
                    self::$instance = new PDO($dsn, $config['username'] ?? 'root', $config['password'] ?? '');
                }

                self::$instance->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                self::$instance->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
                self::$instance->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);

            } catch (PDOException $e) {
                throw new RuntimeException("Database Connection Error: " . $e->getMessage());
            }
        }

        return self::$instance;
    }

    public static function query(string $sql, array $params = []): array
    {
        $start = microtime(true);
        $stmt = self::getInstance()->prepare($sql);
        $stmt->execute($params);
        $result = $stmt->fetchAll();
        self::$queryLog[] = ['sql' => $sql, 'params' => $params, 'time' => microtime(true) - $start];
        return $result;
    }

    public static function queryOne(string $sql, array $params = []): ?array
    {
        $stmt = self::getInstance()->prepare($sql);
        $stmt->execute($params);
        $result = $stmt->fetch();
        return $result ? $result : null;
    }

    public static function execute(string $sql, array $params = []): bool
    {
        $stmt = self::getInstance()->prepare($sql);
        return $stmt->execute($params);
    }

    public static function lastInsertId(): string
    {
        return self::getInstance()->lastInsertId();
    }

    public static function getQueryLog(): array
    {
        return self::$queryLog;
    }
}
