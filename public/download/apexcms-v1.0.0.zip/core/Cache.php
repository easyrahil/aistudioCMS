<?php
declare(strict_types=1);

namespace Apex\Core;

class Cache
{
    private static string $cacheDir = __DIR__ . '/../storage/cache';

    public static function get(string $key): ?string
    {
        $file = self::$cacheDir . '/' . md5($key) . '.cache';
        if (!file_exists($file)) {
            return null;
        }

        $data = unserialize(file_get_contents($file));
        if ($data['expires'] > 0 && time() > $data['expires']) {
            unlink($file);
            return null;
        }

        return $data['content'];
    }

    public static function set(string $key, string $content, int $ttlSeconds = 3600): void
    {
        if (!is_dir(self::$cacheDir)) {
            mkdir(self::$cacheDir, 0755, true);
        }

        $file = self::$cacheDir . '/' . md5($key) . '.cache';
        $data = [
            'expires' => $ttlSeconds > 0 ? time() + $ttlSeconds : 0,
            'content' => $content
        ];
        file_put_contents($file, serialize($data));
    }

    public static function purgeAll(): void
    {
        if (is_dir(self::$cacheDir)) {
            $files = glob(self::$cacheDir . '/*.cache');
            foreach ($files as $file) {
                if (is_file($file)) {
                    unlink($file);
                }
            }
        }
    }
}
