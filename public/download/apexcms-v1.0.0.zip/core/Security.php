<?php
declare(strict_types=1);

namespace Apex\Core;

class Security
{
    public static function generateCsrf(): string
    {
        Session::start();
        if (empty($_SESSION['_csrf_token'])) {
            $_SESSION['_csrf_token'] = bin2hex(random_bytes(32));
        }
        return $_SESSION['_csrf_token'];
    }

    public static function validateCsrf(?string $token): bool
    {
        Session::start();
        if (!$token || empty($_SESSION['_csrf_token'])) {
            return false;
        }
        return hash_equals($_SESSION['_csrf_token'], $token);
    }

    public static function hashPassword(string $password): string
    {
        if (defined('PASSWORD_ARGON2ID')) {
            return password_hash($password, PASSWORD_ARGON2ID, [
                'memory_cost' => 65536,
                'time_cost'   => 4,
                'threads'     => 1,
            ]);
        }
        return password_hash($password, PASSWORD_DEFAULT);
    }

    public static function verifyPassword(string $password, string $hash): bool
    {
        return password_verify($password, $hash);
    }

    public static function checkRateLimit(string $key, int $maxHits = 60, int $windowSeconds = 60): bool
    {
        $cacheFile = __DIR__ . '/../storage/cache/rate_' . md5($key) . '.json';
        $now = time();
        $data = ['count' => 0, 'reset' => $now + $windowSeconds];

        if (file_exists($cacheFile)) {
            $stored = json_decode(file_get_contents($cacheFile), true);
            if ($stored && $stored['reset'] > $now) {
                $data = $stored;
            }
        }

        $data['count']++;
        file_put_contents($cacheFile, json_encode($data));

        return $data['count'] <= $maxHits;
    }
}
