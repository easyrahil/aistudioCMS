<?php
declare(strict_types=1);

namespace Apex\Core;

class Sanitizer
{
    public static function clean(string $data): string
    {
        return htmlspecialchars(trim($data), ENT_QUOTES, 'UTF-8');
    }

    public static function slug(string $title): string
    {
        $slug = preg_replace('~[^\pL\d]+~u', '-', $title);
        $slug = iconv('utf-8', 'us-ascii//TRANSLIT', $slug);
        $slug = preg_replace('~[^-\w]+~', '', $slug);
        $slug = trim($slug, '-');
        $slug = preg_replace('~-+~', '-', $slug);
        return strtolower($slug) ?: 'item';
    }

    public static function cleanHtml(string $html): string
    {
        $allowed = '<p><br><b><strong><i><em><u><h2><h3><h4><h5><h6><ul><ol><li><a><blockquote><code><pre><img><table><thead><tbody>trthtd';
        return strip_tags($html, $allowed);
    }
}
