<?php
declare(strict_types=1);

namespace Apex\Core;

class Hook
{
    private static array $actions = [];
    private static array $filters = [];

    public static function addAction(string $tag, callable $callback, int $priority = 10): void
    {
        self::$actions[$tag][$priority][] = $callback;
    }

    public static function doAction(string $tag, ...$args): void
    {
        if (empty(self::$actions[$tag])) {
            return;
        }

        ksort(self::$actions[$tag]);
        foreach (self::$actions[$tag] as $priorityGroup) {
            foreach ($priorityGroup as $callback) {
                call_user_func_array($callback, $args);
            }
        }
    }

    public static function addFilter(string $tag, callable $callback, int $priority = 10): void
    {
        self::$filters[$tag][$priority][] = $callback;
    }

    public static function applyFilter(string $tag, mixed $value, ...$args): mixed
    {
        if (empty(self::$filters[$tag])) {
            return $value;
        }

        ksort(self::$filters[$tag]);
        foreach (self::$filters[$tag] as $priorityGroup) {
            foreach ($priorityGroup as $callback) {
                $value = call_user_func_array($callback, array_merge([$value], $args));
            }
        }
        return $value;
    }
}
