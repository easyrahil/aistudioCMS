<?php
declare(strict_types=1);

namespace Apex\Core;

class Request
{
    private array $get;
    private array $post;
    private array $server;
    private array $files;
    private ?array $json = null;

    public function __construct()
    {
        $this->get    = $_GET;
        $this->post   = $_POST;
        $this->server = $_SERVER;
        $this->files  = $_FILES;

        $raw = file_get_contents('php://input');
        if ($raw && str_contains($this->header('Content-Type') ?? '', 'application/json')) {
            $this->json = json_decode($raw, true) ?? [];
        }
    }

    public function method(): string
    {
        return strtoupper($this->server['REQUEST_METHOD'] ?? 'GET');
    }

    public function path(): string
    {
        $uri = $this->server['REQUEST_URI'] ?? '/';
        $path = parse_url($uri, PHP_URL_PATH) ?? '/';
        $script = dirname($this->server['SCRIPT_NAME'] ?? '');
        if ($script !== '/' && str_starts_with($path, $script)) {
            $path = substr($path, strlen($script));
        }
        return '/' . trim($path, '/');
    }

    public function input(string $key, mixed $default = null): mixed
    {
        if ($this->json !== null && array_key_exists($key, $this->json)) {
            return $this->json[$key];
        }
        if (array_key_exists($key, $this->post)) {
            return $this->post[$key];
        }
        if (array_key_exists($key, $this->get)) {
            return $this->get[$key];
        }
        return $default;
    }

    public function all(): array
    {
        return array_merge($this->get, $this->post, $this->json ?? []);
    }

    public function header(string $name): ?string
    {
        $header = 'HTTP_' . strtoupper(str_replace('-', '_', $name));
        return $this->server[$header] ?? $this->server[$name] ?? null;
    }

    public function ip(): string
    {
        return $this->server['HTTP_X_FORWARDED_FOR'] ?? $this->server['REMOTE_ADDR'] ?? '127.0.0.1';
    }

    public function isAjax(): bool
    {
        return strtolower($this->header('X-Requested-With') ?? '') === 'xmlhttprequest';
    }
}
