<?php
declare(strict_types=1);

namespace Apex\Core;

class Response
{
    private int $status = 200;
    private array $headers = [];
    private string $content = '';

    public function status(int $status): self
    {
        $this->status = $status;
        return $this;
    }

    public function header(string $name, string $value): self
    {
        $this->headers[$name] = $value;
        return $this;
    }

    public function json(array $data, int $status = 200): void
    {
        $this->status = $status;
        $this->header('Content-Type', 'application/json; charset=utf-8');
        $this->content = json_encode($data, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
        $this->send();
    }

    public function html(string $html, int $status = 200): void
    {
        $this->status = $status;
        $this->header('Content-Type', 'text/html; charset=utf-8');
        $this->content = $html;
        $this->send();
    }

    public function redirect(string $url, int $status = 302): void
    {
        http_response_code($status);
        header("Location: {$url}");
        exit;
    }

    public function send(): void
    {
        http_response_code($this->status);

        // Security headers
        header('X-Content-Type-Options: nosniff');
        header('X-Frame-Options: SAMEORIGIN');
        header('Referrer-Policy: strict-origin-when-cross-origin');

        foreach ($this->headers as $name => $value) {
            header("{$name}: {$value}");
        }

        echo $this->content;
        exit;
    }
}
