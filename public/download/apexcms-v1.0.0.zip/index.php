<?php
declare(strict_types=1);

/**
 * ==============================================================================
 * ApexCMS Root Bootstrap
 * ==============================================================================
 * Resolves seamlessly when the package root (e.g. public_html) is the document root,
 * as well as when requests arrive directly at index.php.
 */

// If installer is not completed, redirect to the web installer
if (!file_exists(__DIR__ . '/install/install.lock')) {
    if (file_exists(__DIR__ . '/install/index.php')) {
        header('Location: /install/');
        exit;
    }
}

// Forward to the front controller
if (file_exists(__DIR__ . '/public/index.php')) {
    require_once __DIR__ . '/public/index.php';
    exit;
}

http_response_code(500);
echo '<!DOCTYPE html><html><body style="font-family:sans-serif;text-align:center;padding:50px;"><h2>ApexCMS Bootstrap Error</h2><p>Cannot find <code>public/index.php</code>. Please ensure all package files are uploaded properly.</p></body></html>';
