-- Default Seed Data for ApexCMS
INSERT INTO `settings` (`key`, `value`) VALUES
('site_name', 'ApexCMS Demo'),
('site_tagline', 'Ultra-Fast Production CMS & E-Commerce'),
('shop_enabled', '1'),
('active_theme', 'magazine'),
('default_locale', 'en'),
('timezone', 'UTC'),
('currency', 'USD'),
('currency_symbol', '$'),
('math_captcha_enabled', '1'),
('cache_enabled', '1'),
('cache_ttl', '3600'),
('ai_provider', 'gemini'),
('ai_model', 'gemini-2.5-flash'),
('homepage_blocks', '[
  {"id": "hero_1", "type": "hero", "enabled": true, "settings": {"title": "Craft Stories That Move the World", "subtitle": "A modern, lightning-fast CMS built for publishers and e-commerce creators who demand 100/100 Core Web Vitals.", "cta_text": "Explore Articles", "cta_link": "#articles", "secondary_cta_text": "Visit Shop", "secondary_cta_link": "/shop"}},
  {"id": "posts_1", "type": "featured_posts", "enabled": true, "settings": {"title": "Editorial Highlights", "limit": 4}},
  {"id": "shop_1", "type": "featured_products", "enabled": true, "settings": {"title": "Featured Curated Products", "limit": 4}},
  {"id": "faq_1", "type": "faq", "enabled": true, "settings": {"title": "Frequently Asked Questions", "items": [{"q": "How is 95+ Core Web Vitals achieved?", "a": "Zero-bloat architecture, inlined critical CSS, self-hosted optimized typography, zero layout shift (CLS=0), and full-page HTML caching with immediate cache invalidation."}, {"q": "Can the shop be disabled?", "a": "Yes! Toggle Settings > Shop > Enable shop off, and all shop routes, cart drawers, and catalog widgets immediately disappear without affecting your blog."}]}},
  {"id": "newsletter_1", "type": "newsletter", "enabled": true, "settings": {"title": "Stay Ahead of the Curve", "subtitle": "Get our weekly technical essays delivered straight to your inbox."}}
]');
