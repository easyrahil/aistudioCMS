-- ApexCMS Complete Production Database Schema
-- UTF-8 Unicode Support (utf8mb4_unicode_ci)
-- Engine: InnoDB with Foreign Key constraints

SET FOREIGN_KEY_CHECKS = 0;

-- 1. Users Table
CREATE TABLE IF NOT EXISTS `users` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `email` VARCHAR(191) NOT NULL UNIQUE,
  `username` VARCHAR(60) NOT NULL UNIQUE,
  `password_hash` VARCHAR(255) NOT NULL,
  `role` ENUM('admin', 'editor', 'user') NOT NULL DEFAULT 'user',
  `status` ENUM('active', 'pending', 'banned') NOT NULL DEFAULT 'active',
  `two_factor_secret` VARCHAR(64) NULL,
  `two_factor_enabled` TINYINT(1) NOT NULL DEFAULT 0,
  `email_verified_at` DATETIME NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX `idx_users_role` (`role`),
  INDEX `idx_users_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 2. Categories
CREATE TABLE IF NOT EXISTS `categories` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(100) NOT NULL,
  `slug` VARCHAR(120) NOT NULL UNIQUE,
  `description` TEXT NULL,
  `type` ENUM('post', 'product') NOT NULL DEFAULT 'post',
  `parent_id` INT UNSIGNED NULL,
  INDEX `idx_categories_type` (`type`),
  CONSTRAINT `fk_cat_parent` FOREIGN KEY (`parent_id`) REFERENCES `categories` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 3. Tags
CREATE TABLE IF NOT EXISTS `tags` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(60) NOT NULL,
  `slug` VARCHAR(80) NOT NULL UNIQUE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 4. Posts & Pages
CREATE TABLE IF NOT EXISTS `posts` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `author_id` INT UNSIGNED NOT NULL,
  `title` VARCHAR(255) NOT NULL,
  `slug` VARCHAR(255) NOT NULL UNIQUE,
  `excerpt` TEXT NULL,
  `body` LONGTEXT NOT NULL,
  `featured_image` VARCHAR(255) NULL,
  `featured_image_alt` VARCHAR(255) NULL,
  `type` ENUM('post', 'page') NOT NULL DEFAULT 'post',
  `status` ENUM('published', 'draft', 'scheduled', 'trash') NOT NULL DEFAULT 'draft',
  `published_at` DATETIME NULL,
  `parent_id` INT UNSIGNED NULL,
  `template` VARCHAR(64) NOT NULL DEFAULT 'default',
  `views_count` INT UNSIGNED NOT NULL DEFAULT 0,
  
  -- SEO Fields
  `seo_title` VARCHAR(255) NULL,
  `seo_description` VARCHAR(320) NULL,
  `seo_focus_keyword` VARCHAR(100) NULL,
  `seo_canonical` VARCHAR(255) NULL,
  `seo_robots` VARCHAR(64) NOT NULL DEFAULT 'index, follow',
  `seo_schema_type` VARCHAR(64) NOT NULL DEFAULT 'Article',

  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX `idx_posts_type_status` (`type`, `status`),
  INDEX `idx_posts_slug` (`slug`),
  CONSTRAINT `fk_posts_author` FOREIGN KEY (`author_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Post Categories Pivot
CREATE TABLE IF NOT EXISTS `post_category` (
  `post_id` INT UNSIGNED NOT NULL,
  `category_id` INT UNSIGNED NOT NULL,
  PRIMARY KEY (`post_id`, `category_id`),
  CONSTRAINT `fk_pc_post` FOREIGN KEY (`post_id`) REFERENCES `posts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_pc_category` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 5. Products (E-Commerce Module)
CREATE TABLE IF NOT EXISTS `products` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `title` VARCHAR(255) NOT NULL,
  `slug` VARCHAR(255) NOT NULL UNIQUE,
  `sku` VARCHAR(64) NOT NULL UNIQUE,
  `type` ENUM('physical', 'digital') NOT NULL DEFAULT 'physical',
  `price` DECIMAL(10,2) NOT NULL,
  `sale_price` DECIMAL(10,2) NULL,
  `stock_quantity` INT NOT NULL DEFAULT 0,
  `stock_status` ENUM('instock', 'outofstock') NOT NULL DEFAULT 'instock',
  `description` LONGTEXT NOT NULL,
  `short_description` TEXT NULL,
  `featured_image` VARCHAR(255) NULL,
  `gallery_images` JSON NULL,
  `attributes` JSON NULL, -- e.g. {"Size": ["S", "M", "L"], "Color": ["Black", "Blue"]}
  `digital_file_path` VARCHAR(255) NULL,
  `download_limit` INT NOT NULL DEFAULT 3,
  `download_expiry_days` INT NOT NULL DEFAULT 7,
  `weight` DECIMAL(8,2) NULL,
  `status` ENUM('published', 'draft', 'trash') NOT NULL DEFAULT 'published',
  
  -- SEO Fields
  `seo_title` VARCHAR(255) NULL,
  `seo_description` VARCHAR(320) NULL,
  `seo_focus_keyword` VARCHAR(100) NULL,

  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX `idx_products_sku` (`sku`),
  INDEX `idx_products_price` (`price`),
  INDEX `idx_products_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 6. Orders
CREATE TABLE IF NOT EXISTS `orders` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `order_number` VARCHAR(32) NOT NULL UNIQUE,
  `user_id` INT UNSIGNED NULL,
  `customer_email` VARCHAR(191) NOT NULL,
  `customer_name` VARCHAR(120) NOT NULL,
  `shipping_address` JSON NULL,
  `billing_address` JSON NULL,
  `subtotal` DECIMAL(10,2) NOT NULL,
  `discount_total` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  `tax_total` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  `shipping_total` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  `grand_total` DECIMAL(10,2) NOT NULL,
  `currency` VARCHAR(3) NOT NULL DEFAULT 'USD',
  `payment_method` VARCHAR(32) NOT NULL,
  `payment_status` ENUM('pending', 'paid', 'failed', 'refunded') NOT NULL DEFAULT 'pending',
  `order_status` ENUM('processing', 'completed', 'cancelled', 'refunded') NOT NULL DEFAULT 'processing',
  `notes` TEXT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX `idx_orders_status` (`order_status`),
  CONSTRAINT `fk_orders_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Order Items
CREATE TABLE IF NOT EXISTS `order_items` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `order_id` INT UNSIGNED NOT NULL,
  `product_id` INT UNSIGNED NULL,
  `product_title` VARCHAR(255) NOT NULL,
  `product_sku` VARCHAR(64) NOT NULL,
  `price` DECIMAL(10,2) NOT NULL,
  `quantity` INT UNSIGNED NOT NULL DEFAULT 1,
  `subtotal` DECIMAL(10,2) NOT NULL,
  `download_token` VARCHAR(64) NULL,
  `downloads_count` INT UNSIGNED NOT NULL DEFAULT 0,
  `token_expires_at` DATETIME NULL,
  CONSTRAINT `fk_oi_order` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 7. Media Library
CREATE TABLE IF NOT EXISTS `media` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `filename` VARCHAR(255) NOT NULL,
  `filepath` VARCHAR(255) NOT NULL,
  `mime_type` VARCHAR(64) NOT NULL,
  `file_size` INT UNSIGNED NOT NULL,
  `alt_text` VARCHAR(255) NULL,
  `title` VARCHAR(255) NULL,
  `dimensions` VARCHAR(32) NULL, -- e.g. "1920x1080"
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 8. Forms & Submissions
CREATE TABLE IF NOT EXISTS `form_submissions` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `form_name` VARCHAR(64) NOT NULL,
  `data` JSON NOT NULL,
  `ip_address` VARCHAR(45) NOT NULL,
  `user_agent` VARCHAR(255) NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 9. SEO Redirects & 404 Monitor
CREATE TABLE IF NOT EXISTS `redirects` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `source_path` VARCHAR(255) NOT NULL UNIQUE,
  `target_url` VARCHAR(255) NOT NULL,
  `status_code` SMALLINT UNSIGNED NOT NULL DEFAULT 301,
  `hits` INT UNSIGNED NOT NULL DEFAULT 0,
  `last_hit_at` DATETIME NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `not_found_logs` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `url` VARCHAR(255) NOT NULL,
  `referrer` VARCHAR(255) NULL,
  `ip_address` VARCHAR(45) NOT NULL,
  `hits` INT UNSIGNED NOT NULL DEFAULT 1,
  `first_seen` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `last_seen` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY `idx_url` (`url`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 10. Settings Table
CREATE TABLE IF NOT EXISTS `settings` (
  `key` VARCHAR(64) PRIMARY KEY,
  `value` LONGTEXT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SET FOREIGN_KEY_CHECKS = 1;
